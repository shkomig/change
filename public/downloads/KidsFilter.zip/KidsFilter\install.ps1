# KidsFilter installer - run as Administrator
# Installs the whitelist DNS filter: copies files to C:\ProgramData\KidsFilter,
# registers a startup task (runs as SYSTEM), points the network adapters at
# 127.0.0.1, blocks external DNS/DoT via firewall, and disables DNS-over-HTTPS
# in Edge/Chrome/Firefox via policy.

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = 'C:\ProgramData\KidsFilter'
$upstreams = @('8.8.8.8', '1.1.1.1')

Write-Host '=== KidsFilter installer ===' -ForegroundColor Cyan

# --- 1. Find Python (pythonw runs without a console window) ---
$py = $null
foreach ($name in 'pythonw.exe', 'python.exe') {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { $py = $cmd.Source; break }
}
if (-not $py) {
    $guess = Get-ChildItem 'C:\Program Files\Python3*\pythonw.exe' -ErrorAction SilentlyContinue |
             Sort-Object FullName -Descending | Select-Object -First 1
    if ($guess) { $py = $guess.FullName }
}
if (-not $py) {
    Write-Host 'ERROR: Python not found.' -ForegroundColor Red
    Write-Host 'Install Python from https://www.python.org/downloads/'
    Write-Host 'IMPORTANT: check "Install for all users" during setup, then re-run this script.'
    exit 1
}
Write-Host "Using Python: $py"

# --- 2. Copy files to ProgramData (admin-writable only) ---
New-Item -ItemType Directory -Force $dest | Out-Null
Copy-Item "$src\dns_filter.py" $dest -Force
if (-not (Test-Path "$dest\allowed.txt")) {
    Copy-Item "$src\allowed.txt" $dest   # keep existing list on re-install
}
# Lock down: only Administrators/SYSTEM may write; kids can only read
icacls $dest /inheritance:r /grant 'Administrators:(OI)(CI)F' 'SYSTEM:(OI)(CI)F' 'Users:(OI)(CI)RX' | Out-Null
Write-Host "Files installed to $dest"

# --- 3. Scheduled task: start the DNS server at boot as SYSTEM ---
schtasks /Delete /TN 'KidsFilterDNS' /F 2>$null | Out-Null
schtasks /Create /TN 'KidsFilterDNS' /TR "`"$py`" `"$dest\dns_filter.py`"" /SC ONSTART /RU SYSTEM /RL HIGHEST /F | Out-Null
schtasks /Run /TN 'KidsFilterDNS' | Out-Null
Write-Host 'Startup task registered and started.'

# --- 4. Verify the server answers before switching system DNS ---
Start-Sleep -Seconds 3
$ok = $false
try {
    Resolve-DnsName 'microsoft.com' -Server 127.0.0.1 -DnsOnly -ErrorAction Stop | Out-Null
    $ok = $true
} catch {}
if (-not $ok) {
    Write-Host 'ERROR: DNS server did not respond on 127.0.0.1. System DNS was NOT changed.' -ForegroundColor Red
    Write-Host "Try running manually to see the error:  `"$py`" `"$dest\dns_filter.py`""
    exit 1
}
Write-Host 'Filter server is answering. Switching system DNS...'

# --- 5. Point all active adapters at the local filter ---
Get-NetAdapter | Where-Object Status -eq 'Up' |
    Set-DnsClientServerAddress -ServerAddresses '127.0.0.1'
Clear-DnsClientCache

# --- 6. Firewall: block outbound DNS (53) and DoT (853) except to our upstreams ---
Get-NetFirewallRule -DisplayName 'KidsFilter*' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
# Everything except the upstream resolvers the filter itself uses:
$blockRanges = @('0.0.0.0-1.1.1.0', '1.1.1.2-8.8.4.3', '8.8.4.5-8.8.8.7', '8.8.8.9-255.255.255.255')
New-NetFirewallRule -DisplayName 'KidsFilter block external DNS (UDP)' -Direction Outbound `
    -Protocol UDP -RemotePort 53 -RemoteAddress $blockRanges -Action Block | Out-Null
New-NetFirewallRule -DisplayName 'KidsFilter block external DNS (TCP)' -Direction Outbound `
    -Protocol TCP -RemotePort 53 -RemoteAddress $blockRanges -Action Block | Out-Null
New-NetFirewallRule -DisplayName 'KidsFilter block DoT (853)' -Direction Outbound `
    -Protocol TCP -RemotePort 853 -Action Block | Out-Null
Write-Host 'Firewall rules created.'

# --- 7. Disable DNS-over-HTTPS in browsers (so they cannot bypass the filter) ---
$policies = @(
    @{ Path = 'HKLM:\SOFTWARE\Policies\Microsoft\Edge';  Name = 'DnsOverHttpsMode'; Value = 'off'; Type = 'String' },
    @{ Path = 'HKLM:\SOFTWARE\Policies\Google\Chrome';   Name = 'DnsOverHttpsMode'; Value = 'off'; Type = 'String' }
)
foreach ($p in $policies) {
    New-Item -Path $p.Path -Force | Out-Null
    New-ItemProperty -Path $p.Path -Name $p.Name -Value $p.Value -PropertyType $p.Type -Force | Out-Null
}
$ffPath = 'HKLM:\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS'
New-Item -Path $ffPath -Force | Out-Null
New-ItemProperty -Path $ffPath -Name 'Enabled' -Value 0 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $ffPath -Name 'Locked'  -Value 1 -PropertyType DWord -Force | Out-Null
Write-Host 'Browser DNS-over-HTTPS disabled by policy.'

Write-Host ''
Write-Host '=== KidsFilter installed successfully ===' -ForegroundColor Green
Write-Host "Allowed sites list : $dest\allowed.txt   (edit as Administrator)"
Write-Host "Blocked requests   : $dest\blocked.log"
Write-Host ''
Write-Host 'REMINDER: make sure the kids use a STANDARD (non-admin) Windows account!' -ForegroundColor Yellow
