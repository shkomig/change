"""KidsFilter - whitelist-only local DNS server.

Listens on 127.0.0.1:53 (UDP + TCP). Domains listed in allowed.txt
(including their subdomains) are forwarded to a real DNS server;
everything else gets NXDOMAIN and is written to blocked.log.

allowed.txt is re-read automatically whenever it changes on disk.
Pure standard library - no pip packages needed.
"""

import os
import socket
import struct
import threading
import time

BASE = os.path.dirname(os.path.abspath(__file__))
ALLOWED_FILE = os.path.join(BASE, "allowed.txt")
BLOCKED_LOG = os.path.join(BASE, "blocked.log")
LISTEN_ADDR = "127.0.0.1"
UPSTREAMS = ["8.8.8.8", "1.1.1.1"]
TIMEOUT = 3.0

_lock = threading.Lock()
_allowed = set()
_mtime = None
_recently_logged = {}  # domain -> last log time (avoid log spam)


def load_allowed():
    global _allowed, _mtime
    try:
        mtime = os.path.getmtime(ALLOWED_FILE)
    except OSError:
        return
    if mtime == _mtime:
        return
    domains = set()
    try:
        with open(ALLOWED_FILE, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.split("#", 1)[0].strip().lower()
                if not line:
                    continue
                line = line.lstrip("*.")
                line = line.rstrip(".")
                if line:
                    domains.add(line)
    except OSError:
        return
    _allowed = domains
    _mtime = mtime
    print("[KidsFilter] loaded %d allowed domains" % len(domains))


def is_allowed(name):
    with _lock:
        load_allowed()
        allowed = _allowed
    name = name.lower().rstrip(".")
    parts = name.split(".")
    for i in range(len(parts)):
        if ".".join(parts[i:]) in allowed:
            return True
    return False


def log_blocked(name):
    now = time.time()
    with _lock:
        last = _recently_logged.get(name, 0)
        if now - last < 300:  # log each domain at most once per 5 minutes
            return
        _recently_logged[name] = now
        if len(_recently_logged) > 5000:
            _recently_logged.clear()
    try:
        with open(BLOCKED_LOG, "a", encoding="utf-8") as f:
            f.write("%s  BLOCKED  %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), name))
    except OSError:
        pass


def parse_qname(data):
    """Extract the queried domain name from a raw DNS query."""
    labels = []
    i = 12
    while i < len(data):
        length = data[i]
        if length == 0:
            i += 1
            break
        if length & 0xC0:  # compression pointer - not expected in a question
            break
        labels.append(data[i + 1:i + 1 + length].decode("ascii", "ignore"))
        i += 1 + length
    return ".".join(labels), i + 4  # +4 skips QTYPE/QCLASS -> end of question


def make_nxdomain(query):
    """Build an NXDOMAIN response echoing the question section."""
    try:
        _, qend = parse_qname(query)
        tid = query[:2]
        rd = query[2] & 0x01
        flags = struct.pack(">H", 0x8003 | (rd << 8) | 0x0080)  # QR,RD,RA,RCODE=3
        header = tid + flags + struct.pack(">HHHH", 1, 0, 0, 0)
        return header + query[12:qend]
    except Exception:
        return b""


def forward_udp(query):
    for server in UPSTREAMS:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(TIMEOUT)
            s.sendto(query, (server, 53))
            resp, _ = s.recvfrom(4096)
            s.close()
            return resp
        except OSError:
            continue
    return b""


def forward_tcp(query):
    for server in UPSTREAMS:
        try:
            s = socket.create_connection((server, 53), timeout=TIMEOUT)
            s.sendall(struct.pack(">H", len(query)) + query)
            hdr = s.recv(2)
            if len(hdr) < 2:
                continue
            (length,) = struct.unpack(">H", hdr)
            resp = b""
            while len(resp) < length:
                chunk = s.recv(length - len(resp))
                if not chunk:
                    break
                resp += chunk
            s.close()
            return resp
        except OSError:
            continue
    return b""


def handle(query, tcp=False):
    if len(query) < 17:
        return b""
    name, _ = parse_qname(query)
    if not name:
        return make_nxdomain(query)
    if is_allowed(name):
        return forward_tcp(query) if tcp else forward_udp(query)
    log_blocked(name)
    return make_nxdomain(query)


def udp_server():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((LISTEN_ADDR, 53))
    print("[KidsFilter] UDP listening on %s:53" % LISTEN_ADDR)
    while True:
        try:
            data, addr = sock.recvfrom(4096)
        except OSError:
            continue

        def work(data=data, addr=addr):
            resp = handle(data, tcp=False)
            if resp:
                try:
                    sock.sendto(resp, addr)
                except OSError:
                    pass

        threading.Thread(target=work, daemon=True).start()


def tcp_server():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((LISTEN_ADDR, 53))
    srv.listen(16)
    print("[KidsFilter] TCP listening on %s:53" % LISTEN_ADDR)
    while True:
        try:
            conn, _ = srv.accept()
        except OSError:
            continue

        def work(conn=conn):
            try:
                conn.settimeout(TIMEOUT)
                hdr = conn.recv(2)
                if len(hdr) < 2:
                    return
                (length,) = struct.unpack(">H", hdr)
                query = b""
                while len(query) < length:
                    chunk = conn.recv(length - len(query))
                    if not chunk:
                        return
                    query += chunk
                resp = handle(query, tcp=True)
                if resp:
                    conn.sendall(struct.pack(">H", len(resp)) + resp)
            except OSError:
                pass
            finally:
                conn.close()

        threading.Thread(target=work, daemon=True).start()


def main():
    load_allowed()
    threading.Thread(target=tcp_server, daemon=True).start()
    udp_server()


if __name__ == "__main__":
    main()
