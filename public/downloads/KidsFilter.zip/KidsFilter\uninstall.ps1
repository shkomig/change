# KidsFilter uninstaller - run as Administrator
# Reverses everything install.ps1 did.

#Requires -RunAsAdministrator
$ErrorActionPreference = 'Continue'

Write-Host '=== KidsFilter uninstaller ===' -ForegroundColor Cyan

# Restore automatic (DHCP) DNS on all adapters FIRST so the network keeps working
Get-NetAdapter | Set-DnsClientServerAddress -ResetServerAddresses
Clear-DnsClientCache
Write-Host 'System DNS restored to automatic (DHCP).'

# Stop and remove the startup task
schtasks /End    /TN 'KidsFilterDNS' /F 2>$null | Out-Null
schtasks /Delete /TN 'KidsFilterDNS' /F 2>$null | Out-Null
Get-Process pythonw, python -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -and (Get-CimInstance Win32_Process -Filter "ProcessId=$($_.Id)").CommandLine -like '*dns_filter.py*' } |
    Stop-Process -Force -ErrorAction SilentlyContinue
Write-Host 'Startup task removed.'

# Remove firewall rules
Get-NetFirewallRule -DisplayName 'KidsFilter*' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
Write-Host 'Firewall rules removed.'

# Remove browser DoH policies
Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' -Name 'DnsOverHttpsMode' -ErrorAction SilentlyContinue
Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Google\Chrome'  -Name 'DnsOverHttpsMode' -ErrorAction SilentlyContinue
Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS' -Recurse -ErrorAction SilentlyContinue
Write-Host 'Browser policies removed.'

# Remove installed files (keeps nothing behind)
Remove-Item 'C:\ProgramData\KidsFilter' -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Files removed.'

Write-Host ''
Write-Host '=== KidsFilter fully removed ===' -ForegroundColor Green
